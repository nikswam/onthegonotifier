package niknetprojex.autosender;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.ActionBarActivity;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Set;

public class ServiceFile extends Service {

        private BluetoothAdapter mBluetoothAdapter;
        private ArrayAdapter<String> itemsAdapter;
        private int REQUEST_ENABLE_BT = 2;
        private Criteria criteria;
        private MyLocationListener myLocListener;
        private boolean connected = false;
        private boolean connectedSMS = false;
        private LocationManager locationManager;



        private class MyLocationListener implements LocationListener {
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }
            public void onLocationChanged(Location loc) {
                if (connected==true) {
                    sendSMSmessage();
                    connectedSMS = true;
                    locationManager.removeUpdates(myLocListener);
                }
                else {

                }
            }
            public void onProviderEnabled(String provider) {

            }
            public void onProviderDisabled(String provider){

            }
        }
        private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                CharSequence text = "";

                if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                    text = "Bluetooth device: " + device.getName() + "connected";
                    displayToast(text, context);
                    connected = true;
                    startLocationListener();
                    sendSMSmessage();
                } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                    text = "Bluetooth device: " + device.getName() + "disconnected";
                    displayToast(text, context);
                    connected = false;
                    if (connectedSMS==true) {
                        sendSMSmessageYe();
                        connectedSMS = false;
                        locationManager.removeUpdates(myLocListener);
                    }

                }

            }
        };
        protected boolean isSelectedDevice(BluetoothDevice device){
            SharedPreferences prefer = getApplicationContext().getSharedPreferences("user_settings", MODE_PRIVATE);
            Set<String> abc = prefer.getStringSet("multi_choice_prefs", null);
            String [] selectedDevices = abc.toArray(new String[abc.size()]);
            if (Arrays.asList(selectedDevices).contains(device.getAddress())){
                return true;
            }
            else
                return false;

        }

        protected void displayToast (CharSequence text, Context context) {
            Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0 , 0);
            toast.show();
        }
        protected void sendSMSmessage(){
            SharedPreferences prefer = getApplicationContext().getSharedPreferences("user_settings", MODE_PRIVATE);
            String phoneNo = prefer.getString("sms_number_preference", null);
            String message = prefer.getString("departure_text_preference", "I left");

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, message , null, null);
                Toast.makeText(getApplicationContext(), "Text Sent", Toast.LENGTH_LONG).show();
            }
            catch (Exception e){
                Toast.makeText(getApplicationContext(), "Text Failed to Send", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

        }
        protected void sendSMSmessageYe(){
            SharedPreferences prefer = getApplicationContext().getSharedPreferences("user_settings", MODE_PRIVATE);
            String phoneNo = prefer.getString("sms_number_preference", null);
            String message = prefer.getString("departure_text_preference", "I left");

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, message , null, null);
                Toast.makeText(getApplicationContext(), "Text Sent", Toast.LENGTH_LONG).show();
            }
            catch (Exception e){
                Toast.makeText(getApplicationContext(), "Text Failed to Send", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

        }


        protected void startLocationListener(){
            int minTime = 300000;
            float minDistance = 500;
            myLocListener = new MyLocationListener();
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            criteria = new Criteria();
            criteria.setPowerRequirement(Criteria.POWER_LOW);
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            criteria.setCostAllowed(false);
            String bestProvider = locationManager.getBestProvider(criteria, false);
            Location loc = locationManager.getLastKnownLocation(bestProvider);
            locationManager.requestLocationUpdates(bestProvider, minTime, minDistance, myLocListener);
        }



    public void onCreate(){
        super.onCreate();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter != null) {
            //If device supports bluetooth
            //check if bluetooth is enabled
            //listen for connection/disconnection events
            IntentFilter filter1 = new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED);
            IntentFilter filter2 = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED);
            this.registerReceiver(mReceiver, filter1);
            this.registerReceiver(mReceiver, filter2);
            startLocationListener();
        }

    }
    public void onDestroy() {
        this.unregisterReceiver(mReceiver);
        super.onDestroy();
    }
    public int onStartCommand(Intent intent, int flags, int startId) {
        return Service.START_STICKY;
    }
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }
}
